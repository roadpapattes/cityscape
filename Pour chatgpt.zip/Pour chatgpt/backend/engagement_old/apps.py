from django.apps import AppConfig

class EngagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'engagement'
    verbose_name = "Engagement (Sessions & Ratings)"
